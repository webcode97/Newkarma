/**
 * Tiny slider big module
 * Copyright (c) 2022 Gian MR
 * Gian MR Theme Custom Javascript
 *
 * @package newkarma
 */	
 (function( slider ) {
	"use strict";
		var element = document.getElementById( 'bigmoduleslide' );
		if ( typeof( element ) != 'undefined' && element != null ) {
			var slider = tns({
				container: '.gmr-big-carousel',
				loop: true,
				gutter: 0,
				edgePadding: 0,
				items: 1,
				lazyload: true,
				swipeAngle: false,
				mouseDrag: true,
				autoplay: true,
				autoplayButtonOutput: false,
				controls: false,
				nav: true,
				responsive : {
					0 : {
						items : 1,
					},
					250 : {
						items : 1,
					},
					400 : {
						items : 1,
					},
					600 : {
						items : 1,
					},
					1000 : {
						items : 1,
					}
				}
			});
		}
	})( window.slider );
	