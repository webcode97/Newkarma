/**
 * Tiny slider module
 * Copyright (c) 2022 Gian MR
 * Gian MR Theme Custom Javascript
 *
 * @package newkarma
 */	
 (function( slider ) {
	"use strict";
		var element = document.getElementById( 'moduleslide' );
		if ( typeof( element ) != 'undefined' && element != null ) {
			var slider = tns({
				container: '.gmr-owl-carousel',
				loop: true,
				gutter: 0,
				edgePadding: 0,
				controlsText: ['&laquo;', '&raquo;'],
				items: 3,
				lazyload: true,
				swipeAngle: false,
				mouseDrag: true,
				autoplay: true,
				autoplayButtonOutput: false,
				nav: false,
				responsive : {
					0 : {
						items : 1,
					},
					250 : {
						items : 2,
					},
					400 : {
						items : 2,
					},
					600 : {
						items : 3,
					},
					1000 : {
						items : 3,
					}
				}
			});
		}
	})( window.slider );
	